
import React from 'react';


const Accessorise = () => {
  
  
  return (
    <div >
   <h1>Accessorise PAGE</h1>
   
    </div>
  );
};

export default Accessorise;
