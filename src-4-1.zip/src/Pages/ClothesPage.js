
import React from 'react';


const ClothesPage = () => {
  
  
  return (
    <div >
   <h1>CLOTHES PAGE</h1>
   
    </div>
  );
};

export default ClothesPage;
