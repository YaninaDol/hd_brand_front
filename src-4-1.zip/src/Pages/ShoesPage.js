
import React from 'react';


const ShoesPage = () => {
  
  
  return (
    <div >
   <h1>SHOES PAGE</h1>
   
    </div>
  );
};

export default ShoesPage;
