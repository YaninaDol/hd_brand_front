
import React from 'react';


const FAQ = () => {
  
  
  return (
    <div >
   <h1>TEXT ABOUT SHOE CARE</h1>
   
    </div>
  );
};

export default FAQ;
