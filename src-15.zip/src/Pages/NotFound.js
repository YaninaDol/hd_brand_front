import React from 'react';

const NotFound = () => {
  return (
    <div>
      <h2>404 - Page Not Found</h2>
      <p>Sorry, the requested page does not exist.</p>
      {/* You can add additional content, styling, or links here */}
    </div>
  );
};

export default NotFound;