
import React from 'react';
import PxMainPage from './PxMainPage';

const FAQ = () => {
  
  
  return (
    <div >
    <PxMainPage />
   
    </div>
  );
};

export default FAQ;
